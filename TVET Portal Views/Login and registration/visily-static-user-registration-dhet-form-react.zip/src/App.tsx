function App() {
  return (
    <>
      <div data-type="PAGE" className="relative w-[1661px] h-[1084px] bg-[#eef2ee]/[1] overflow-y-auto overflow-x-hidden">
  <div data-type="CONTAINER" className="w-[1841px] h-[1101px] absolute top-[0px] left-[-90px] z-[1] bg-[#000000]/[0] opacity-[1]">
    <div data-role="CONTAINER_CHILDREN_WRAPPER" className="relative z-[0] w-full h-full rounded-[inherit] overflow-hidden">
      <div data-type="OVAL" className="absolute top-[-351px] left-[-168px] z-[3] w-[1037px] h-[1194px] bg-[radial-gradient(ellipse_71%_71%_at_50%_50%,_#007A4Dff_0%,_#007A4D00_70%)] rounded-[100%] blur-[70px] opacity-[0.32]" />
      <div data-type="OVAL" className="absolute top-[-231px] left-[732px] z-[2] w-[1202px] h-[1020px] bg-[radial-gradient(ellipse_71%_71%_at_50%_50%,_#FFB612ff_0%,_#FFB61200_70%)] rounded-[100%] blur-[70px] opacity-[0.27]" />
      <div data-type="GROUP" className="absolute top-[23px] left-[130px] z-[5] w-[313px] h-[73px] opacity-[1]">
        <div className="relative w-full h-full">
          <div data-type="IMAGE" className="absolute top-[0px] left-[0px] z-[0] w-[118px] h-[73px] rounded-[2px] opacity-[1] overflow-hidden">
            <img src="./assets/IMG_1.jpg" className="absolute max-w-none max-h-none top-[-16px] left-[0px] w-[118px] h-[105px]" />
          </div>
          <span data-type="TEXT" className="absolute top-[13px] left-[135px] z-[1] whitespace-pre text-[#182B22]/[1] font-[Inter] text-[32px] leading-[48px] font-[700] text-left tracking-[-1px] opacity-[1]">TVET Portal</span>
        </div>
      </div>
      <div data-type="CONTAINER" className="w-[740px] h-[862px] absolute top-[120px] left-[593px] z-[4] bg-[#f3f8f6]/[1] rounded-[32px] shadow-[0px_20px_25px_0px_#0000001a,_0px_8px_10px_0px_#0000001a] backdrop-blur-[12px] opacity-[1]">
        <div data-role="CONTAINER_CHILDREN_WRAPPER" className="relative z-[0] w-full h-full rounded-[inherit] overflow-hidden">
          <span data-type="TEXT" className="absolute top-[60px] left-[88px] z-[2] whitespace-pre text-[#2E2C42]/[1] font-[Inter] text-[40px] leading-[54px] font-[700] text-left tracking-[0px] opacity-[1]">Registration details</span>
          <div data-type="DIVIDER" className="absolute top-[129px] left-[87px] z-[13] w-[597px] h-[0px] border-t-[4px] border-[#efb034]/[0.22]" />
          <span data-type="TEXT" className="absolute top-[144px] left-[90px] z-[3] whitespace-pre text-[#97A0B9]/[1] font-[Inter] text-[18px] leading-[27px] font-[400] text-left tracking-[0px] opacity-[1]">.</span>
          <div data-type="CONTAINER" className="w-[168px] h-[52px] absolute top-[175px] left-[260px] z-[5] bg-[#0e6a3a]/[1] rounded-[10px] opacity-[1]">
            <div data-role="CONTAINER_CHILDREN_WRAPPER" className="relative z-[0] w-full h-full rounded-[inherit]">
              <button data-type="BUTTON" className="absolute top-[4px] left-[4px] z-[0] min-w-[86px] h-[44px] flex items-center justify-center gap-[0px] bg-[#ffffff]/[1] rounded-[8px] shadow-[0px_1px_3px_0px_#0000001a,_0px_1px_2px_0px_#0000001a] opacity-[1]">
                <span className="whitespace-nowrap text-[15px] leading-[24px] font-[600] font-[Inter] text-[#4A4D6A]/[1]"> DHET </span>
              </button>
              <button data-type="BUTTON" className="absolute top-[4px] left-[90px] z-[1] min-w-[86px] h-[44px] flex items-center justify-center gap-[0px] bg-[#000000]/[0] opacity-[1]">
                <span className="whitespace-nowrap text-[15px] leading-[24px] font-[600] font-[Inter] text-[#ffffff]/[1]"> TVET </span>
              </button>
            </div>
          </div>
          <span data-type="TEXT" className="absolute top-[189px] left-[88px] z-[4] whitespace-pre text-[#4A4D6A]/[1] font-[Inter] text-[16px] leading-[24px] font-[600] text-left tracking-[0px] opacity-[1]">Organization Type</span>
          <div data-type="TEXTBOX" data-style="standard" className="absolute top-[275px] left-[88px] z-[6] w-[287px] h-[88px] opacity-[1]">
            <div data-role="ELEMENT_WITH_LABEL_CONTENT_WRAPPER" className="flex flex-col justify-center h-full w-full">
              <label data-style="BASIC" className="block pb-[12px] z-10 text-[15px] font-[600] font-[Inter] text-[#4A4D6A]/[1]"> Full name<span className="text-[#EA916E]/[1]">*</span>
              </label>
              <div data-role="ELEMENT_WITH_LABEL_INPUT_WRAPPER" className="relative flex items-center w-full flex-grow py-[8px] px-[16px] bg-[#f8f9fa]/[1] border-[1px] border-[#F0F4F8]/[1] rounded-[10px] shadow-[0px_0px_2px_0px_#171a1f1f,_0px_4px_9px_0px_#171a1f1c] gap-[6px]">
                <img className="w-[20px] h-[20px] text-[#97A0B9]/[1]" data-icon="Lucide_user_Outlined" src="./assets/IMG_2.svg" />
                <input type="text" value="" placeholder="John Doe" className="w-full flex-1 text-[#97A0B9]/[1] text-[14px] leading-[22px] font-[400] font-[Inter] text-left placeholder:text-[#97A0B9]/[1] outline-none bg-transparent border-none" />
              </div>
            </div>
          </div>
          <div data-type="TEXTBOX" data-style="standard" className="absolute top-[275px] left-[396px] z-[7] w-[287px] h-[88px] opacity-[1]">
            <div data-role="ELEMENT_WITH_LABEL_CONTENT_WRAPPER" className="flex flex-col justify-center h-full w-full">
              <label data-style="BASIC" className="block pb-[12px] z-10 text-[15px] font-[600] font-[Inter] text-[#4A4D6A]/[1]"> Institutional Email<span className="text-[#EA916E]/[1] font-['Open_Sans']">*</span>
              </label>
              <div data-role="ELEMENT_WITH_LABEL_INPUT_WRAPPER" className="relative flex items-center w-full flex-grow py-[8px] px-[16px] bg-[#f8f9fa]/[1] border-[1px] border-[#F0F4F8]/[1] rounded-[10px] shadow-[0px_0px_2px_0px_#171a1f1f,_0px_4px_9px_0px_#171a1f1c] gap-[6px]">
                <img className="w-[20px] h-[20px] text-[#97A0B9]/[1]" data-icon="Lucide_mail_Outlined" src="./assets/IMG_3.svg" />
                <input type="text" value="" placeholder="j.doe@institution.edu" className="w-full flex-1 text-[#97A0B9]/[1] text-[14px] leading-[22px] font-[400] font-[Inter] text-left placeholder:text-[#97A0B9]/[1] outline-none bg-transparent border-none" />
              </div>
            </div>
          </div>
          <div data-type="TEXTBOX" data-style="standard" className="absolute top-[402px] left-[88px] z-[8] w-[287px] h-[88px] opacity-[1]">
            <div data-role="ELEMENT_WITH_LABEL_CONTENT_WRAPPER" className="flex flex-col justify-center h-full w-full">
              <label data-style="BASIC" className="block pb-[12px] z-10 text-[15px] font-[600] font-[Inter] text-[#4A4D6A]/[1]"> Role<span className="text-[#EA916E]/[1] font-['Open_Sans']">*</span>
              </label>
              <div data-role="ELEMENT_WITH_LABEL_INPUT_WRAPPER" className="relative flex items-center w-full flex-grow py-[8px] px-[16px] bg-[#f8f9fa]/[1] border-[1px] border-[#F0F4F8]/[1] rounded-[10px] shadow-[0px_0px_2px_0px_#171a1f1f,_0px_4px_9px_0px_#171a1f1c] gap-[6px]">
                <img className="w-[20px] h-[20px] text-[#97A0B9]/[1]" data-icon="Lucide_book-user_Outlined" src="./assets/IMG_4.svg" />
                <input type="text" value="" placeholder="" className="w-full flex-1 text-[#97A0B9]/[1] text-[14px] leading-[22px] font-[400] font-[Inter] text-left placeholder:text-[#97A0B9]/[1] outline-none bg-transparent border-none" />
              </div>
            </div>
          </div>
          <div data-type="TEXTBOX" data-style="standard" className="absolute top-[402px] left-[401px] z-[10] w-[287px] h-[88px] opacity-[1]">
            <div data-role="ELEMENT_WITH_LABEL_CONTENT_WRAPPER" className="flex flex-col justify-center h-full w-full">
              <label data-style="BASIC" className="block pb-[12px] z-10 text-[15px] font-[600] font-[Inter] text-[#4A4D6A]/[1]"> PERSAL Number<span className="text-[#EA916E]/[1] font-['Open_Sans']">*</span>
              </label>
              <div data-role="ELEMENT_WITH_LABEL_INPUT_WRAPPER" className="relative flex items-center w-full flex-grow py-[8px] px-[16px] bg-[#f8f9fa]/[1] border-[1px] border-[#F0F4F8]/[1] rounded-[10px] shadow-[0px_0px_2px_0px_#171a1f1f,_0px_4px_9px_0px_#171a1f1c] gap-[6px]">
                <img className="w-[20px] h-[20px] text-[#97A0B9]/[1]" data-icon="Lucide_hash_Outlined" src="./assets/IMG_5.svg" />
                <input type="text" value="" placeholder="" className="w-full flex-1 text-[#97A0B9]/[1] text-[14px] leading-[22px] font-[400] font-[Inter] text-left placeholder:text-[#97A0B9]/[1] outline-none bg-transparent border-none" />
              </div>
            </div>
          </div>
          <div data-type="GROUP" className="absolute top-[521px] left-[87px] z-[9] w-[287px] h-[119px] opacity-[1]">
            <div className="relative w-full h-full">
              <span data-type="TEXT" className="absolute top-[0px] left-[3px] z-[3] w-[83px] h-[48px] text-[#4a4d6a]/[1] font-[Inter] text-[15px] leading-[24px] font-[600] text-left opacity-[1]">Password<span className="text-[#EA916E]/[1]">*</span></span>
              <div data-type="TEXTBOX" data-style="standard" className="absolute top-[32px] left-[0px] z-[0] w-[287px] h-[47px] opacity-[1]">
                <div data-role="ELEMENT_WITH_LABEL_CONTENT_WRAPPER" className="flex flex-col justify-center h-full w-full">
                  <div data-role="ELEMENT_WITH_LABEL_INPUT_WRAPPER" className="relative flex items-center w-full flex-grow px-[12px] bg-[#f8f9fa]/[1] border-[1px] border-[#dee1e6]/[1] rounded-[6px] shadow-[0px_0px_2px_0px_#171a1f1f,_0px_4px_9px_0px_#171a1f1c] gap-[6px]">
                    <img className="w-[16px] h-[16px] text-[#565e6c]/[1]" data-icon="Lucide_lock_Outlined" src="./assets/IMG_6.svg" />
                    <input type="text" value="" placeholder="••••••••" className="w-full flex-1 text-[#565e6c]/[1] text-[14px] leading-[22px] font-[400] font-[Inter] text-left placeholder:text-[#565e6c]/[1] outline-none bg-transparent border-none" />
                  </div>
                </div>
              </div>
              <img data-type="ICON" className="absolute top-[48px] left-[254px] z-[5] w-[14px] h-[14px] text-[#125895]/[1] opacity-[1]" data-icon="Nucleo_eye_outlined" src="./assets/IMG_7.svg" />
              <span data-type="TEXT" className="absolute top-[87px] left-[19px] z-[2] w-[176px] h-[32px] text-[#de3b40]/[0.53] font-[Inter] text-[11px] leading-[16px] font-[400] text-left tracking-[0px] opacity-[1]">Min. 8 characters with numbers</span>
              <img data-type="ICON" className="absolute top-[88px] left-[3px] z-[2] w-[10px] h-[10px] text-[#de3b40]/[1] opacity-[0.6]" data-icon="Lucide_info_Outlined" src="./assets/IMG_8.svg" />
            </div>
          </div>
          <div data-type="CONTAINER" className="w-[283px] h-[6px] absolute top-[566px] left-[176px] z-[0] bg-[#000000]/[0] rounded-[9999px] opacity-[1]">
            <div data-role="CONTAINER_CHILDREN_WRAPPER" className="relative z-[0] w-full h-full rounded-[inherit] overflow-hidden">
            </div>
          </div>
          <button data-type="BUTTON" className="absolute top-[666px] left-[218px] z-[12] min-w-[382px] h-[48px] px-[16px] flex items-center justify-center gap-[0px] bg-[linear-gradient(90deg,_#0A8A59ff_0%,_#7DA638ff_100%)] rounded-[10px] shadow-[0px_10px_15px_0px_#0000001a,_0px_4px_6px_0px_#0000001a] opacity-[1]">
            <span className="whitespace-nowrap text-[16px] leading-[26px] font-[600] font-[Inter] text-[#ffffff]/[1]"> Submit registration </span>
          </button>
          <div data-type="GROUP" className="absolute top-[729px] left-[301px] z-[11] w-[215px] h-[20px] opacity-[1]">
            <div className="relative w-full h-full">
              <span data-type="TEXT" className="absolute top-[0px] left-[0px] z-[0] whitespace-pre text-[#171a1f]/[1] font-[Inter] text-[12px] leading-[20px] font-[500] text-left opacity-[1]">Already have an Account ?</span>
              <span data-type="TEXT" className="absolute top-[0px] left-[154px] z-[1] whitespace-pre text-[#c9a227]/[1] font-[Inter] text-[12px] leading-[20px] font-[500] text-left opacity-[1]">Login here</span>
            </div>
          </div>
          <div data-type="GROUP" className="absolute top-[814px] left-[246px] z-[1] w-[283px] h-[6px] opacity-[1]">
            <div className="relative w-full h-full">
              <div data-type="RECTANGLE" className="absolute top-[0px] left-[0px] z-[0] w-[43px] h-[6px] bg-[#EA4335]/[1] opacity-[1]" />
              <div data-type="RECTANGLE" className="absolute top-[0px] left-[42px] z-[1] w-[57px] h-[6px] bg-[#4285F4]/[1] opacity-[1]" />
              <div data-type="RECTANGLE" className="absolute top-[0px] left-[99px] z-[2] w-[43px] h-[6px] bg-[#34A853]/[1] opacity-[1]" />
              <div data-type="RECTANGLE" className="absolute top-[0px] left-[141px] z-[3] w-[43px] h-[6px] bg-[#FBBC05]/[1] opacity-[1]" />
              <div data-type="RECTANGLE" className="absolute top-[0px] left-[183px] z-[4] w-[57px] h-[6px] bg-[#EA4335]/[1] opacity-[1]" />
              <div data-type="RECTANGLE" className="absolute top-[0px] left-[240px] z-[5] w-[43px] h-[6px] bg-[#4285F4]/[1] opacity-[1]" />
            </div>
          </div>
        </div>
      </div>
      <div data-type="OVAL" className="absolute top-[462px] left-[-88px] z-[1] w-[1247px] h-[1026px] bg-[radial-gradient(ellipse_71%_71%_at_50%_50%,_#1E4FD8ff_0%,_#1E4FD800_70%)] rounded-[100%] blur-[70px] opacity-[0.16]" />
      <div data-type="OVAL" className="absolute top-[491px] left-[810px] z-[0] w-[1383px] h-[997px] bg-[radial-gradient(ellipse_71%_71%_at_50%_50%,_#DE3831ff_0%,_#DE383100_70%)] rounded-[100%] blur-[70px] opacity-[0.22]" />
    </div>
  </div>
  <div data-type="RECTANGLE" className="absolute top-[790px] left-[559px] z-[0] w-[322px] h-[77px] bg-[#BBD2C5]/[1] rounded-[9999px] blur-[60px] opacity-[0.2]" />
</div>

    </>
  )
}

export default App
