function App() {
  return (
    <>
      <div data-type="PAGE" className="relative w-[1661px] h-[1084px] bg-[#eef2ee]/[1] overflow-y-auto overflow-x-hidden">
  <div data-type="CONTAINER" className="w-[1841px] h-[1101px] absolute top-[0px] left-[-90px] z-[1] bg-[#000000]/[0] opacity-[1]">
    <div data-role="CONTAINER_CHILDREN_WRAPPER" className="relative z-[0] w-full h-full rounded-[inherit] overflow-hidden">
      <div data-type="OVAL" className="absolute top-[-351px] left-[-168px] z-[3] w-[1037px] h-[1194px] bg-[radial-gradient(ellipse_71%_71%_at_50%_50%,_#007A4Dff_0%,_#007A4D00_70%)] rounded-[100%] blur-[70px] opacity-[0.32]" />
      <div data-type="OVAL" className="absolute top-[-231px] left-[732px] z-[2] w-[1202px] h-[1020px] bg-[radial-gradient(ellipse_71%_71%_at_50%_50%,_#FFB612ff_0%,_#FFB61200_70%)] rounded-[100%] blur-[70px] opacity-[0.27]" />
      <div data-type="GROUP" className="absolute top-[23px] left-[130px] z-[5] w-[313px] h-[73px] opacity-[1]">
        <div className="relative w-full h-full">
          <div data-type="IMAGE" className="absolute top-[0px] left-[0px] z-[0] w-[118px] h-[73px] rounded-[2px] opacity-[1] overflow-hidden">
            <img src="./assets/IMG_1.jpg" className="absolute max-w-none max-h-none top-[-16px] left-[0px] w-[118px] h-[105px]" />
          </div>
          <span data-type="TEXT" className="absolute top-[13px] left-[135px] z-[1] whitespace-pre text-[#182B22]/[1] font-[Inter] text-[32px] leading-[48px] font-[700] text-left tracking-[-1px] opacity-[1]">TVET Portal</span>
        </div>
      </div>
      <div data-type="CONTAINER" className="w-[630px] h-[637px] absolute top-[232px] left-[606px] z-[4] bg-[#f3f8f6]/[1] rounded-[32px] shadow-[0px_20px_25px_0px_#0000001a,_0px_8px_10px_0px_#0000001a] backdrop-blur-[12px] opacity-[1]">
        <div data-role="CONTAINER_CHILDREN_WRAPPER" className="relative z-[0] w-full h-full rounded-[inherit] overflow-hidden">
          <span data-type="TEXT" className="absolute top-[76px] left-[271px] z-[7] whitespace-pre text-[#182B22]/[1] font-[Inter] text-[40px] leading-[48px] font-[700] text-left tracking-[-1px] opacity-[1]">Login</span>
          <div data-type="DIVIDER" className="absolute top-[138px] left-[119px] z-[8] w-[392px] h-[0px] border-t-[4px] border-[#efb034]/[0.22]" />
          <div data-type="TEXTBOX" data-style="standard" className="absolute top-[181px] left-[126px] z-[3] w-[382px] h-[80px] opacity-[1]">
            <div data-role="ELEMENT_WITH_LABEL_CONTENT_WRAPPER" className="flex flex-col justify-center h-full w-full">
              <label data-style="BASIC" className="block pb-[11px] z-10 text-[13px] leading-[22px] font-[500] font-[Inter] text-[#697C73]/[1]"> Email address </label>
              <div data-role="ELEMENT_WITH_LABEL_INPUT_WRAPPER" className="relative flex items-center w-full flex-grow py-[8px] px-[12px] bg-[#f8f9fa]/[1] rounded-[10px] shadow-[0px_0px_2px_0px_#171a1f1f,_0px_4px_9px_0px_#171a1f1c] gap-[6px]">
                <input type="text" value="planning@dhet.gov.za" placeholder="" className="w-full flex-1 text-[#3E4744]/[1] text-[14px] leading-[22px] font-[400] font-[Inter] text-left outline-none bg-transparent border-none" />
              </div>
            </div>
          </div>
          <div data-type="TEXTBOX" data-style="standard" className="absolute top-[281px] left-[126px] z-[5] w-[382px] h-[80px] opacity-[1]">
            <div data-role="ELEMENT_WITH_LABEL_CONTENT_WRAPPER" className="flex flex-col justify-center h-full w-full">
              <label data-style="BASIC" className="block pb-[11px] z-10 text-[13px] leading-[22px] font-[500] font-[Inter] text-[#697C73]/[1]"> Password </label>
              <div data-role="ELEMENT_WITH_LABEL_INPUT_WRAPPER" className="relative flex items-center w-full flex-grow py-[8px] px-[12px] bg-[#f8f9fa]/[1] rounded-[10px] shadow-[0px_0px_2px_0px_#171a1f1f,_0px_4px_9px_0px_#171a1f1c] gap-[6px]">
                <input type="text" value="••••••••••••" placeholder="" className="w-full flex-1 text-[#242F2C]/[1] text-[14px] leading-[22px] font-[400] font-[Inter] text-left outline-none bg-transparent border-none" />
              </div>
            </div>
          </div>
          <button data-type="BUTTON" className="absolute top-[401px] left-[126px] z-[4] min-w-[382px] h-[48px] px-[16px] flex items-center justify-center gap-[0px] bg-[linear-gradient(90deg,_#0A8A59ff_0%,_#7DA638ff_100%)] rounded-[10px] shadow-[0px_10px_15px_0px_#0000001a,_0px_4px_6px_0px_#0000001a] opacity-[1]">
            <span className="whitespace-nowrap text-[16px] leading-[26px] font-[600] font-[Inter] text-[#ffffff]/[1]"> Sign in </span>
          </button>
          <button data-type="BUTTON" className="absolute top-[465px] left-[324px] z-[1] min-w-[99px] h-[22px] flex items-center justify-center gap-[0px] bg-[#000000]/[0] opacity-[1]">
            <span className="whitespace-nowrap text-[13px] leading-[22px] font-[500] font-[Inter] text-[#c9a227]/[1]"> Request access </span>
          </button>
          <span data-type="TEXT" className="absolute top-[467px] left-[220px] z-[0] whitespace-pre text-[#3E514B]/[1] font-[Inter] text-[13px] leading-[20px] font-[400] text-left tracking-[0px] opacity-[1]">New institution?</span>
          <div data-type="GROUP" className="absolute top-[528px] left-[176px] z-[6] w-[283px] h-[6px] opacity-[1]">
            <div className="relative w-full h-full">
              <div data-type="RECTANGLE" className="absolute top-[0px] left-[0px] z-[0] w-[43px] h-[6px] bg-[#EA4335]/[1] opacity-[1]" />
              <div data-type="RECTANGLE" className="absolute top-[0px] left-[42px] z-[1] w-[57px] h-[6px] bg-[#4285F4]/[1] opacity-[1]" />
              <div data-type="RECTANGLE" className="absolute top-[0px] left-[99px] z-[2] w-[43px] h-[6px] bg-[#34A853]/[1] opacity-[1]" />
              <div data-type="RECTANGLE" className="absolute top-[0px] left-[141px] z-[3] w-[43px] h-[6px] bg-[#FBBC05]/[1] opacity-[1]" />
              <div data-type="RECTANGLE" className="absolute top-[0px] left-[183px] z-[4] w-[57px] h-[6px] bg-[#EA4335]/[1] opacity-[1]" />
              <div data-type="RECTANGLE" className="absolute top-[0px] left-[240px] z-[5] w-[43px] h-[6px] bg-[#4285F4]/[1] opacity-[1]" />
            </div>
          </div>
          <div data-type="CONTAINER" className="w-[283px] h-[6px] absolute top-[591px] left-[176px] z-[2] bg-[#000000]/[0] rounded-[9999px] opacity-[1]">
            <div data-role="CONTAINER_CHILDREN_WRAPPER" className="relative z-[0] w-full h-full rounded-[inherit] overflow-hidden">
            </div>
          </div>
        </div>
      </div>
      <div data-type="OVAL" className="absolute top-[462px] left-[-88px] z-[1] w-[1247px] h-[1026px] bg-[radial-gradient(ellipse_71%_71%_at_50%_50%,_#1E4FD8ff_0%,_#1E4FD800_70%)] rounded-[100%] blur-[70px] opacity-[0.16]" />
      <div data-type="OVAL" className="absolute top-[491px] left-[810px] z-[0] w-[1383px] h-[997px] bg-[radial-gradient(ellipse_71%_71%_at_50%_50%,_#DE3831ff_0%,_#DE383100_70%)] rounded-[100%] blur-[70px] opacity-[0.22]" />
    </div>
  </div>
  <div data-type="RECTANGLE" className="absolute top-[790px] left-[559px] z-[0] w-[322px] h-[77px] bg-[#BBD2C5]/[1] rounded-[9999px] blur-[60px] opacity-[0.2]" />
</div>

    </>
  )
}

export default App
